<?php

namespace Sisfin\Models;

class AlunoService
{
    private $_alunoRepository;

    /**
     * @param $_alunoRepository
     */
    public function __construct()
    {
        $this->_alunoRepository = array();
        $arquivo = __DIR__.'/../AppData/alunos.dat';

        $file = fopen($arquivo, "r");
        while (($line = fgets($file)) !== false) {
            $reg = explode(";", $line);
            array_push($this->_alunoRepository, new Aluno($reg[0], $reg[2], $reg[1]));
        }
    }
}